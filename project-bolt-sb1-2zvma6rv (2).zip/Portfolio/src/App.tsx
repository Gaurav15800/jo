import React from 'react';
import Hero from './components/Hero';
import SocialSidebar from './components/SocialSidebar';
import Projects from './components/Projects';
import Skills from './components/Skills';
import InterpersonalSkills from './components/InterpersonalSkills';
import Certifications from './components/Certifications';
import Testimonials from './components/Testimonials';
import WhyChooseMe from './components/WhyChooseMe';
import ThankYou from './components/ThankYou';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <SocialSidebar />
      <Hero />
      <Projects />
      <Skills />
      <InterpersonalSkills />
      <Certifications />
      <Testimonials />
      <WhyChooseMe />
      <ThankYou />
    </div>
  );
}

export default App;