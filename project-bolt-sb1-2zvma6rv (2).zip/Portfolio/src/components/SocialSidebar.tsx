import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, Linkedin, Facebook, Phone } from 'lucide-react';

const SocialSidebar = () => {
  const [copiedEmail, setCopiedEmail] = useState(false);

  const socialLinks = [
    {
      icon: Mail,
      label: 'Email',
      action: () => {
        navigator.clipboard.writeText('gaurav@example.com');
        setCopiedEmail(true);
        setTimeout(() => setCopiedEmail(false), 2000);
      },
    },
    {
      icon: Linkedin,
      label: 'LinkedIn',
      href: 'https://linkedin.com',
    },
    {
      icon: Facebook,
      label: 'Facebook',
      href: 'https://facebook.com',
    },
    {
      icon: Phone,
      label: 'WhatsApp',
      href: 'https://wa.me/1234567890',
    },
  ];

  return (
    <motion.div
      initial={{ x: -100 }}
      animate={{ x: 0 }}
      className="fixed left-4 top-1/2 -translate-y-1/2 z-50"
    >
      <div className="flex flex-col gap-4">
        {socialLinks.map((link, index) => (
          <motion.div
            key={link.label}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            {link.href ? (
              <a
                href={link.href}
                target="_blank"
                rel="noopener noreferrer"
                className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-shadow"
              >
                <link.icon className="w-6 h-6 text-primary-600" />
              </a>
            ) : (
              <button
                onClick={link.action}
                className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-shadow relative group"
              >
                <link.icon className="w-6 h-6 text-primary-600" />
                {copiedEmail && link.label === 'Email' && (
                  <span className="absolute -right-20 bg-black text-white text-sm py-1 px-2 rounded">
                    Copied!
                  </span>
                )}
              </button>
            )}
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default SocialSidebar;