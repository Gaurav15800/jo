import React from 'react';
import { motion } from 'framer-motion';
import { Heart, Mail } from 'lucide-react';

const ThankYou = () => {
  return (
    <section className="py-20 bg-white" id="thank-you">
      <div className="container mx-auto px-4 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="max-w-2xl mx-auto"
        >
          <Heart className="w-12 h-12 text-red-500 mx-auto mb-6" />
          <h2 className="text-4xl font-bold text-gray-800 mb-4">Thank You for Visiting!</h2>
          <p className="text-gray-600 mb-8">
            I appreciate you taking the time to explore my portfolio. Let's connect and create something amazing together!
          </p>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="bg-gradient-to-r from-primary-500 to-secondary-500 text-white px-8 py-3 rounded-full font-semibold inline-flex items-center hover:shadow-lg transition-shadow"
          >
            <Mail className="w-5 h-5 mr-2" />
            Get in Touch
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
};

export default ThankYou;