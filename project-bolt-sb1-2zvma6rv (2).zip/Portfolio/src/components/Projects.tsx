import React from 'react';
import { motion } from 'framer-motion';
import { ExternalLink, Calendar, Award, ArrowRight } from 'lucide-react';

const projects = [
  {
    title: 'Global E-commerce SEO Transformation',
    role: 'SEO Strategist',
    duration: 'Jan 2024 - Present',
    description: 'Led a comprehensive SEO overhaul for a multinational e-commerce platform, focusing on technical optimization and content strategy.',
    achievements: [
      'Increased organic traffic by 300%',
      'Improved mobile rankings for 1000+ keywords',
      'Reduced page load time by 60%'
    ],
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    category: 'SEO'
  },
  {
    title: 'SaaS Social Media Growth Campaign',
    role: 'Social Media Director',
    duration: 'Oct 2023 - Dec 2023',
    description: 'Developed and executed a multi-platform social media strategy for a leading SaaS company.',
    achievements: [
      'Grew following from 10K to 100K',
      'Achieved 500% increase in engagement',
      'Generated 5000+ qualified leads'
    ],
    image: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    category: 'Social Media'
  },
  {
    title: 'Enterprise Content Strategy Revamp',
    role: 'Content Strategist',
    duration: 'Jul 2023 - Sep 2023',
    description: 'Redesigned content strategy for a Fortune 500 company, focusing on thought leadership and lead generation.',
    achievements: [
      'Created 100+ high-performing articles',
      'Increased blog traffic by 250%',
      'Improved conversion rate by 40%'
    ],
    image: 'https://images.unsplash.com/photo-1542435503-956c469947f6?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    category: 'Content'
  },
  {
    title: 'B2B Digital Marketing Campaign',
    role: 'Digital Marketing Lead',
    duration: 'Apr 2023 - Jun 2023',
    description: 'Spearheaded a comprehensive digital marketing campaign for a B2B tech company.',
    achievements: [
      'Generated $2M in qualified pipeline',
      'Reduced CAC by 45%',
      'Increased marketing ROI by 300%'
    ],
    image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    category: 'Marketing'
  },
  {
    title: 'E-commerce Analytics Implementation',
    role: 'Analytics Specialist',
    duration: 'Feb 2023 - Mar 2023',
    description: 'Set up comprehensive analytics and tracking system for a major e-commerce platform.',
    achievements: [
      'Implemented advanced tracking for 50+ KPIs',
      'Created automated reporting system',
      'Improved data accuracy by 95%'
    ],
    image: 'https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    category: 'Analytics'
  },
  {
    title: 'Startup Growth Acceleration',
    role: 'Growth Strategist',
    duration: 'Dec 2022 - Jan 2023',
    description: 'Developed and executed growth strategy for an AI startup, focusing on market penetration and user acquisition.',
    achievements: [
      'Achieved 400% user growth in 3 months',
      'Secured 3 major partnerships',
      'Reduced customer acquisition cost by 60%'
    ],
    image: 'https://images.unsplash.com/photo-1559136555-9303baea8ebd?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    category: 'Growth'
  }
];

const Projects = () => {
  const [selectedCategory, setSelectedCategory] = React.useState('All');
  const categories = ['All', ...new Set(projects.map(project => project.category))];

  const filteredProjects = selectedCategory === 'All' 
    ? projects 
    : projects.filter(project => project.category === selectedCategory);

  return (
    <section className="py-20 bg-gray-900" id="projects">
      <div className="container mx-auto px-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl font-bold mb-4 text-white">Featured Projects</h2>
          <p className="text-gray-400 max-w-2xl mx-auto mb-8">
            Explore some of my most impactful work across different domains of digital marketing
          </p>

          <div className="flex flex-wrap justify-center gap-3 mb-12">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-6 py-2 rounded-full text-sm font-medium transition-all ${
                  selectedCategory === category
                    ? 'bg-gradient-to-r from-primary-500 to-secondary-500 text-white'
                    : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project, index) => (
            <motion.div
              key={project.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-gray-800 rounded-2xl overflow-hidden group hover:shadow-2xl hover:shadow-primary-500/10 transition-all duration-300"
            >
              <div className="relative h-48 overflow-hidden">
                <img 
                  src={project.image} 
                  alt={project.title}
                  className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900 to-transparent opacity-60" />
                <span className="absolute top-4 right-4 bg-gray-900/80 text-white px-3 py-1 rounded-full text-sm backdrop-blur-sm">
                  {project.category}
                </span>
              </div>
              
              <div className="p-6">
                <div className="flex items-center text-gray-400 text-sm mb-2">
                  <Calendar className="w-4 h-4 mr-2" />
                  <span>{project.duration}</span>
                </div>
                
                <h3 className="text-xl font-semibold mb-2 text-white">{project.title}</h3>
                
                <div className="text-primary-400 font-medium mb-3 flex items-center">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  <span>{project.role}</span>
                </div>
                
                <p className="text-gray-400 mb-4 line-clamp-2">{project.description}</p>
                
                <div className="space-y-2 mb-4">
                  {project.achievements.map((achievement, i) => (
                    <div key={i} className="flex items-start">
                      <Award className="w-4 h-4 text-secondary-400 mt-1 mr-2 flex-shrink-0" />
                      <span className="text-sm text-gray-400">{achievement}</span>
                    </div>
                  ))}
                </div>

                <button className="text-primary-400 font-medium flex items-center group/btn hover:text-primary-300 transition-colors">
                  View Project Details
                  <ArrowRight className="w-4 h-4 ml-2 group-hover/btn:translate-x-1 transition-transform" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;