import React from 'react';
import { motion } from 'framer-motion';
import { 
  Brain, Users, Clock, Lightbulb, MessageSquare, 
  HeartHandshake, Scale, Book, HandshakeIcon, Rocket, 
  Zap, Ear
} from 'lucide-react';

const skills = [
  { name: 'Problem-Solving', icon: Brain },
  { name: 'Teamwork', icon: Users },
  { name: 'Time Management', icon: Clock },
  { name: 'Open-Mindedness', icon: Lightbulb },
  { name: 'Communication', icon: MessageSquare },
  { name: 'Critical Thinking', icon: Scale },
  { name: 'Patience', icon: Clock },
  { name: 'Relationship Building', icon: HeartHandshake },
  { name: 'Self-Learning', icon: Book },
  { name: 'Self-Motivation', icon: Rocket },
  { name: 'Decision-Making', icon: Zap },
  { name: 'Active Listening', icon: Ear }
];

const InterpersonalSkills = () => {
  return (
    <section className="py-20 bg-white" id="interpersonal-skills">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <HandshakeIcon className="w-12 h-12 text-primary-500 mx-auto mb-4" />
          <h2 className="text-4xl font-bold text-gray-800 mb-4">Interpersonal Skills</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Soft skills that complement my technical expertise and drive successful collaborations
          </p>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {skills.map((skill, index) => (
            <motion.div
              key={skill.name}
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: 1.05 }}
              className="bg-gray-50 rounded-xl p-6 text-center hover:bg-gradient-to-br hover:from-primary-50 hover:to-secondary-50 transition-all duration-300"
            >
              <skill.icon className="w-8 h-8 text-primary-500 mx-auto mb-3" />
              <h3 className="font-semibold text-gray-800">{skill.name}</h3>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default InterpersonalSkills;