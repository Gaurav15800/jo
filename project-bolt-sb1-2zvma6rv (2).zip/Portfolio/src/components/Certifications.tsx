import React from 'react';
import { motion } from 'framer-motion';
import { Award, ExternalLink } from 'lucide-react';

const certifications = [
  {
    title: 'Advanced SEO Mastery',
    institute: 'Google Digital Academy',
    year: '2023',
    description: 'Comprehensive training in advanced SEO techniques and strategies',
    logo: 'https://images.unsplash.com/photo-1573167243872-43c6433b9d40?ixlib=rb-1.2.1&auto=format&fit=crop&w=120&q=80'
  },
  {
    title: 'Social Media Marketing Expert',
    institute: 'Meta Blueprint',
    year: '2023',
    description: 'Professional certification in social media marketing and advertising',
    logo: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?ixlib=rb-1.2.1&auto=format&fit=crop&w=120&q=80'
  },
  {
    title: 'Content Strategy & Marketing',
    institute: 'HubSpot Academy',
    year: '2022',
    description: 'Advanced content strategy and inbound marketing certification',
    logo: 'https://images.unsplash.com/photo-1493612276216-ee3925520721?ixlib=rb-1.2.1&auto=format&fit=crop&w=120&q=80'
  },
  {
    title: 'Digital Analytics',
    institute: 'Google Analytics Academy',
    year: '2022',
    description: 'Professional certification in digital analytics and data interpretation',
    logo: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-1.2.1&auto=format&fit=crop&w=120&q=80'
  }
];

const Certifications = () => {
  return (
    <section className="py-20 bg-gray-50" id="certifications">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <Award className="w-12 h-12 text-primary-500 mx-auto mb-4" />
          <h2 className="text-4xl font-bold text-gray-800 mb-4">Certifications</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Professional certifications that validate my expertise and commitment to continuous learning
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {certifications.map((cert, index) => (
            <motion.div
              key={cert.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2 }}
              className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow duration-300"
            >
              <div className="flex items-center mb-4">
                <img
                  src={cert.logo}
                  alt={cert.institute}
                  className="w-12 h-12 rounded-lg object-cover mr-4"
                />
                <div className="flex-1">
                  <p className="text-sm text-primary-600 font-medium">{cert.year}</p>
                  <h3 className="font-semibold text-gray-800 line-clamp-2">{cert.title}</h3>
                </div>
              </div>
              
              <div className="mb-3">
                <p className="text-sm text-gray-600">{cert.institute}</p>
              </div>
              
              <p className="text-sm text-gray-600 mb-4 line-clamp-2">{cert.description}</p>
              
              <button className="text-primary-600 text-sm font-medium flex items-center hover:text-primary-700 transition-colors">
                View Certificate
                <ExternalLink className="w-4 h-4 ml-1" />
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Certifications;